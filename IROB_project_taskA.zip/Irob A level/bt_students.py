#!/usr/bin/env python

import py_trees as pt, py_trees_ros as ptr, rospy
from behaviours_student import *
from reactive_sequence import RSequence

class BehaviourTree(ptr.trees.BehaviourTree):

	def __init__(self):
		# self.name = "bt_students.py C"

		rospy.loginfo("Initialising behaviour tree")

		# C LEVEL:
		# 
		# Detect cube
		# Complete picking task 
		# Carry cube to second table
		# Complete placing task
		# Cube placed on table?
		#     Yes: end of task
		#     No: go back to initial state in front of table 1

		# # tuck the arm
		# b0 = tuckarm()
		
		
		# # lower head
		# b1 = movehead("down")
		
		
		# # localize cube
		# b2 = cube_localized()
		
		# # pick up cube
		# b3 = pick_up_cube()

		# # turn to table2
		# b4 = moveb(0.5, 0, 64, "Rotate to table 2")

		# # go to table2
		# b5 = moveb(0, 0.5, 21, "Move to table 1")

		# # place cube
		# b6 = place_cube()

		# go_to_table1 = pt.composites.Sequence(name = "move to table 1", 
		# 			children = [moveb(-0.5, 0, 64, "Rotate to table 1"), moveb(0, 0.5, 21, "Go to table 1")]
		# 			)

		# # Checking cube is on table 2, if not move to table 1
		# b7 = pt.composites.Selector(
		# 	name="Detect cube",
		# 	children=[cube_localized(), go_to_table1]
		# )

		# # become the tree
		# tree = RSequence(name="Main sequence", children=[b0, b1, b2, b3, b4, b5, b6, b7])
		
		# A Level
		# 
		# Robot has localized itself in the apartment
		# Navigation to picking pose
		# Cube detected
		# Complete picking task 
		# Navigation with cube to second table
		# Complete placing task
		# Cube placed on table?
		# 	Yes: end of mission
		# 	No: go back to state 2 and repeat until success. For this, you need to respawn the cube to its original pose in case it has fallen.

		b_head_up = pt.composites.Selector(
			name="Is head up?", 
			children=[
				is_head("up"),
				movehead("up")
			]
		)

		b_head_down = pt.composites.Selector(
			name="Is head down?", 
			children=[
				is_head("down"),
				movehead("down")
			]
		)

		b_tuck_arm = pt.composites.Selector(
			name="Is arm tuck?", 
			children=[
				is_arm_tuck(),
				tuckarm()
			]
		)

		# b_pickup_cube = pt.composites.Selector(
		# 	name="Is arm tuck?", 
		# 	children=[
		# 		is_holding_cube(),
		# 		pick_up_cube()
		# 	]
		# )

		# b_move_table1 = pt.composites.Selector(
		# 	name="Move to table 1 branch",
		# 	children = [
		# 		is_robot_at_table("table1"),
		# 		is_holding_cube(), 
		# 		pt.composites.Sequence(
		# 			name="Move table 1 execution",
		# 			children = [
		# 				b_head_up,
		# 				b_tuck_arm,
		# 				move_base_to_table("table_1")
		# 			]
		# 		)
		# 	]
		# )

		# b_move_table2 = pt.composites.Selector(
		# 	name="Move to table 2 branch",
		# 	children = [
		# 		is_robot_at_table("table2"),
		# 		pt.composites.Sequence(
		# 			name="Move to table 2 execution",
		# 			children = [
		# 				b_head_up,
		# 				b_tuck_arm,
		# 				move_base_to_table("table_2")
		# 			]
		# 		)
		# 	]
		# )

		# is_done_check = pt.composites.Sequence(
		# 	name="Is done check",
		# 	children=[
		# 		is_robot_at_table("table2"),
		# 		b_head_down,
		# 		pt.composites.Selector(
		# 			name="Is cube localize?", 
		# 			children=[
		# 				cube_localized()
		# 				# respawn_cube()
		# 			]
		# 		),
		# 	]
		# )

		# # localize the robot
		# b_localize_robot = pt.composites.Selector(
		# 	name="Localize robot",
		# 	children=[
		# 		is_robot_localized(),
		# 		relocalize_robot()
		# 	]
		# )

		# b_pickup_place = pt.composites.Sequence(
		# 	name="Pick and place branch",
		# 	children = [
		# 		b_move_table1,
		# 		b_pickup_cube, 
		# 		b_move_table2, 
		# 		place_cube()
		# 	]
		# )

		# b_execution = pt.composites.Selector(
		# 	name="Execution branch",
		# 	children=[
		# 		is_done_check, 
		# 		b_pickup_place
		# 	]
		# )

		# pick_place_task = pt.composites.Sequence(
		# 	name="Pick and place task",
		# 	children=[
		# 		move_base_to_table("table_1"),
		# 		movehead("down"),
		# 		cube_localized(),
		# 		pick_up_cube(),
		# 		movehead("up"),
		# 		move_base_to_table("table_2"),
		# 		place_cube(),
		# 		movehead("down"),
 		# 		cube_localized()
		# 	]
		# )
		Relocalize_seq = pt.composites.Sequence(
					name="Relocalize seq",
					children=[
						b_head_up,
						# b_tuck_arm,
						relocalize_robot()
					]
				)

		Is_robot_localized_branch = pt.composites.Selector(
			name="Is robot localized branch",
			children=[
				is_robot_localized(),
				Relocalize_seq
			]
		)

		Is_robot_at_table_2_branch = pt.composites.Selector(
			name="Is robot at table 2 branch",
			children=[
				is_robot_at_table("table_2"),
				pt.composites.Sequence(
					name="Move to table 2 branch",
					children=[
						b_head_up,
						# b_tuck_arm,
						move_base_to_table("table_2")
					]
				)
			]
		)

		Is_robot_at_table_1_branch = pt.composites.Selector(
			name="Is robot at table 1 branch",
			children=[
				is_robot_at_table("table_1"),
				pt.composites.Sequence(
					name="Move to table 1 branch",
					children=[
						b_head_up,
						b_tuck_arm,
						move_base_to_table("table_1")
					]
				)
			]
		)

		Is_object_on_target_seq = pt.composites.Sequence(
			name="Is object on target? seq",
			children=[
				is_cube_on_table_2_belief(),
				is_robot_at_table("table_2"),
				b_head_down,
				pt.composites.Selector(
					name="Is cube detected?",
					children=[
						cube_localized(),
						reset_cube_belief()
					]
				)
				
			]
		)

		Localize_respawn_branch = pt.composites.Selector(
			name="Localize/ Respawn cube",
			children=[
				cube_localized(),
				respawn_cube()
			]
		)

		Pickup_cube_seq = pt.composites.Sequence(
			name="Pickup cube seq",
			children=[
				Is_robot_at_table_1_branch,
				b_head_down,
				Localize_respawn_branch,
				pick_up_cube()
			]
		)

		Is_holding_cube_branch = pt.composites.Selector(
			name="Is holding cube? branch",
			children=[
				is_holding_cube(),
				Pickup_cube_seq
			]
		)


		Place_on_table_2_seq = pt.composites.Sequence(
			name="Place on table 2",
			children=[
				Is_holding_cube_branch,
				Is_robot_at_table_2_branch,
				place_cube()
			]
		)

		Is_cube_on_table_2_branch = pt.composites.Selector(
			name="Is cube on table 2?",
			children=[
				Is_object_on_target_seq,
				Place_on_table_2_seq
			]
		)
		
		# MOVE UP THE FOKEN HEAD!!! It sees the floor as a wall!
		tree = RSequence(
			name="Main sequence", 
			children=[
				Is_robot_localized_branch,
				Is_cube_on_table_2_branch
			]
		)



		super(BehaviourTree, self).__init__(tree)

		# Print BT
		rospy.loginfo(pt.display.ascii_tree(tree=tree))

		# execute the behaviour tree
		rospy.sleep(5)
		self.setup(timeout=10000)
		while not rospy.is_shutdown(): self.tick_tock(1)	

if __name__ == "__main__":


	rospy.init_node('main_state_machine')
	try:
		BehaviourTree()
	except rospy.ROSInterruptException:
		pass

	rospy.spin()
